dimensions = (200, 50)
for dimension in dimensions:
    print(dimension)